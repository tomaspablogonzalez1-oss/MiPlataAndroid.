package com.miplata.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Context.dataStore by preferencesDataStore(name = "mi_plata_data")
private val MOVEMENTS_KEY = stringPreferencesKey("movements_json")

data class Movement(
    val id: Long,
    val title: String,
    val amount: Long,
    val isIncome: Boolean,
    val category: String,
    val date: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MiPlataApp(this) }
    }
}

private fun money(value: Long): String =
    NumberFormat.getCurrencyInstance(Locale("es", "AR")).format(value)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MiPlataApp(context: Context) {
    var movements by remember { mutableStateOf<List<Movement>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }
    var isIncome by remember { mutableStateOf(true) }
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("General") }
    var selectedTab by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        val raw = context.dataStore.data.first()[MOVEMENTS_KEY] ?: "[]"
        movements = try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Movement(o.getLong("id"), o.getString("title"), o.getLong("amount"),
                    o.getBoolean("income"), o.getString("category"), o.getLong("date"))
            }.sortedByDescending { it.date }
        } catch (_: Exception) { emptyList() }
        loaded = true
    }

    suspend fun save(list: List<Movement>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(JSONObject().put("id", m.id).put("title", m.title)
                .put("amount", m.amount).put("income", m.isIncome)
                .put("category", m.category).put("date", m.date))
        }
        context.dataStore.edit { it[MOVEMENTS_KEY] = arr.toString() }
    }

    val now = System.currentTimeMillis()
    val monthMovements = movements.filter {
        val d = Date(it.date); val n = Date(now)
        val fmt = SimpleDateFormat("yyyy-MM", Locale.US)
        fmt.format(d) == fmt.format(n)
    }
    val incomeTotal = monthMovements.filter { it.isIncome }.sumOf { it.amount }
    val expenseTotal = monthMovements.filter { !it.isIncome }.sumOf { it.amount }
    val balance = movements.sumOf { if (it.isIncome) it.amount else -it.amount }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Mi Plata", fontWeight = FontWeight.Bold) }) },
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    title = ""; amountText = ""; category = "General"; isIncome = true; showDialog = true
                }) { Icon(Icons.Default.Add, contentDescription = "Agregar movimiento") }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Add, null) }, label = { Text("Resumen") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Remove, null) }, label = { Text("Movimientos") })
                }
            }
        ) { padding ->
            if (!loaded) {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (selectedTab == 0) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp)) {
                                Text("Saldo actual", style = MaterialTheme.typography.titleMedium)
                                Text(money(balance), style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(16.dp))
                                Text("Ingresos de este mes: ${money(incomeTotal)}")
                                Text("Gastos de este mes: ${money(expenseTotal)}")
                                Text("Balance mensual: ${money(incomeTotal - expenseTotal)}",
                                    fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    item { Text("Últimos movimientos", style = MaterialTheme.typography.titleLarge) }
                    items(movements.take(8), key = { it.id }) { m -> MovementRow(m) }
                    if (movements.isEmpty()) item {
                        Text("Todavía no hay movimientos. Tocá + para registrar tu primer ingreso o gasto.")
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { Text("Todos los movimientos", style = MaterialTheme.typography.titleLarge) }
                    items(movements, key = { it.id }) { m ->
                        MovementRow(m)
                        TextButton(onClick = {
                            movements = movements.filterNot { it.id == m.id }
                        }) { Text("Eliminar") }
                    }
                }
            }
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("Nuevo movimiento") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = isIncome, onClick = { isIncome = true }, label = { Text("Ingreso") })
                            FilterChip(selected = !isIncome, onClick = { isIncome = false }, label = { Text("Gasto") })
                        }
                        OutlinedTextField(value = title, onValueChange = { title = it },
                            label = { Text("Descripción") }, singleLine = true)
                        OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' || c == ',' } },
                            label = { Text("Importe en pesos") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true)
                        OutlinedTextField(value = category, onValueChange = { category = it },
                            label = { Text("Categoría") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val parsed = amountText.replace(".", "").replace(",", ".").toDoubleOrNull()
                        if (title.isNotBlank() && parsed != null && parsed > 0) {
                            val item = Movement(System.currentTimeMillis(), title.trim(),
                                parsed.toLong(), isIncome, category.ifBlank { "General" }, System.currentTimeMillis())
                            val newList = (listOf(item) + movements).sortedByDescending { it.date }
                            movements = newList
                            kotlinx.coroutines.MainScope().launch { save(newList) }
                            showDialog = false
                        }
                    }) { Text("Guardar") }
                },
                dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancelar") } }
            )
        }
    }
}

@Composable
private fun MovementRow(m: Movement) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(m.title, fontWeight = FontWeight.SemiBold)
                Text("${m.category} · ${SimpleDateFormat("dd/MM/yyyy", Locale("es", "AR")).format(Date(m.date))}",
                    style = MaterialTheme.typography.bodySmall)
            }
            Text(
                (if (m.isIncome) "+ " else "− ") + money(m.amount),
                color = if (m.isIncome) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
