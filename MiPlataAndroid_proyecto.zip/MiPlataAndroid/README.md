# Mi Plata — proyecto inicial Android

Esta es una base inicial de una app Android nativa en Kotlin/Jetpack Compose.
Incluye registro de ingresos y gastos, saldo total, resumen mensual y almacenamiento local mediante DataStore.

## Cómo generar el APK
1. En una computadora, instala Android Studio y el Android SDK (API 35).
2. Descomprime este proyecto y abre la carpeta `MiPlataAndroid` en Android Studio.
3. Espera a que termine la sincronización de Gradle.
4. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio mostrará la ubicación del APK generado.

## Importante
- Este proyecto es un punto de partida y debe compilarse y probarse en Android Studio antes de instalarlo.
- Los datos se guardan en el almacenamiento privado de la app en el dispositivo. Desinstalar la app puede borrar sus datos.
- La función de eliminar movimiento actualiza la pantalla, pero en esta versión inicial todavía necesita guardar la eliminación de forma persistente; conviene corregirla antes de usarla con registros importantes.
- No conecta con bancos ni billeteras y no sustituye un sistema de contabilidad.
